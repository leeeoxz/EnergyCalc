# Leonardo Santos #
# June 2017 #

import copy


class itpRead ():
	titleSym = ["[","]"] #TITLE SYMBOL
	columnNameSym = [";"] #COLUMN NAME SYMBOL
	content = [] #CONTENT OF FILE
	titles = [] #TITLES
	columnNames = [] #COUMN NAMES

	def __init__(self,FileName):
		file = open(FileName,"r")
		titleCont = []
		for line in file:
			if line[0] in self.titleSym:
				self.titles.append(line.replace("[","").replace("]","").replace("\n","").replace(" ",""))
		print self.titles


itpRead("ffnonbonded.itp")